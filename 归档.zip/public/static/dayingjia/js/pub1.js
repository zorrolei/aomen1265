﻿var _0x43b8 = ["domain", "236767.com", "indexOf", "236767.com", "236767.com", "236767.com", "href", "https://www-08200.com", "value", "attr", "top", "offset", "animate", "html,body", "click", ".nav2 ul li a"];
$(function() {
	$ym = document[_0x43b8[0]];
	if ($ym[_0x43b8[2]](_0x43b8[1]) < 0 && $ym[_0x43b8[2]](_0x43b8[3]) < 0 && $ym[_0x43b8[2]](_0x43b8[4]) < 0 && $ym[_0x43b8[2]](_0x43b8[5]) < 0) {
		//location[_0x43b8[6]] = _0x43b8[7]
	};
	$(_0x43b8[15])[_0x43b8[14]](function() {
		var _0x96fex1 = $(this)[_0x43b8[9]](_0x43b8[8]);
		$(_0x43b8[13])[_0x43b8[12]]({
			scrollTop: $(_0x96fex1)[_0x43b8[11]]()[_0x43b8[10]] - 85
		}, 500)
	})
})